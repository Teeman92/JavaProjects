// Author : David Langan
// Modified with additional comments by Derek Snow
// For    : CIS230 Binary File Example
// This file demos how to create binary files and how to
// do either sequential or direct access reading of such files.  It also shows
// how one can do an update to such a file via direct access to the record to alter.
// Also shown is how we can compute the number of records in such a file based on
// using the sizeof(MyClass) to get the byte size of each record of that type.
// A few utility functions are also demonstrated.
// This code as shown below has been tested using Visual C++ .Net. For simplicity,
// the class declaration and definition are put into one file here instead of using
// the more typical header-file and CPP file.
#include <fstream>
#include <iostream>
#include <string>
using namespace std;

class MyClass
{
    private:
        int x;
        float y;

    public:
        MyClass():x(0), y(0){}

        void set(int newX, float newY)
        {
            x = newX;
            y = newY;
        }


        // The next two methods write the object out to a file or fill it from
        // a read activity.
        void writeIt(fstream& out) const;
        void readIt(fstream& input) const;

        friend ostream& operator<<(ostream& out, const MyClass& someObject);
};

// Class Methods ============================
void MyClass::writeIt(fstream& out) const
{
    // write out the MyClass object
    out.write((char*) this, sizeof(MyClass));
}

void MyClass::readIt(fstream& input) const
{
    // read in the MyClass object
    input.read((char*) this, sizeof(MyClass));
}

// Class Friends ============================
ostream& operator <<(ostream& out, const MyClass& someObject)
{
    out << someObject.x << " -- " << someObject.y << endl;
    return out;
}

// Free Functions ============================
void positionReadHead(fstream& input, long recordNumber)
{
    // Set position of get pointer (seekg)
    // First record number is 0.
    input.seekg((recordNumber) * (sizeof(MyClass)));
}

void positionWriteHead(fstream& input, long recordNumber)
{
    // Set position of put pointer
    // First record number is 0.
    input.seekp((recordNumber) * (sizeof(MyClass)));
}

bool fileExists(char* filename)
{
    ifstream tryIt(filename, ios::in);
    // tryIt would hold a NULL value (i.e. 0) if the file does not exist
    // Remember that 0 is false in C++
    if (!tryIt)
    {
        return false;
    }
    else
    {
        tryIt.close();
        return true;
    }
} // End of fileExists function

long fileSize(char* filename)
{
    ifstream tryIt(filename, ios::in);

    // check to see if the file exists
    if (!tryIt)
    {
        return -1;
    }
    else
    {
        // off - offset to be applied relative to an absolute position specified in the dir
        // dir - specifies an absolute position from where the offset parameter off is applied
        // seekg(off, dir)
        tryIt.seekg(0, ios::end);

        // tellg returns the absolute position of the get pointer
        long answer = tryIt.tellg();
        tryIt.close();
        return answer;
    }
} // End of fileSize
int main(void)
{

    char outputFileName[80];
    do
    {
        cout << "Enter a name (not now in use) for an output file : ";
        cin >> outputFileName;

        if (fileExists(outputFileName))
        {
            cout << "A file by that name already exists!  Try again." << endl;
        }

    } while (fileExists(outputFileName));

    // Create an fstream object and associate it with the file outputFileName for writing (out) binary
    // Available access modes:
    // ios::in      - open file for reading
    // ios::out     - open file for writing
    // ios::trunc   - truncate the file to have size 0 before reading/writing
    // ios::binary  - open file in binary mode (not text mode)
    fstream outputFile(outputFileName, ios::out | ios::binary);
    if (!outputFile)
    {
        cout << "Unable to open '" << outputFileName << "' for output." << endl;
        return (1);
    }
    else
    {
        cout << "Output file correctly opened." << endl;
    }

    // Create a MyClass object using default constructor
    MyClass myObject;

    // write out 14 records using the same MyClass object
    for (int i = 1; i < 15; i++)
    {

        // modify object before each write
        myObject.set(i, i * 2.0f);

        // Note that the write advances the
        // file pointer to the next position
        myObject.writeIt(outputFile);
    }

    // closes the file associated with outputFile,
    // so outputFileName is no longer associated with outputFile
    outputFile.close();

    // Now reread the file sequentially displaying its contents.
    outputFile.open(outputFileName, ios::in | ios::binary); // Reuse same filename.
    if (!outputFile)
    {
        cout << "Unable to open '" << outputFileName << "' for re-reading."
                << endl;
        return (1);
    }
    else
    {
        cout << "File correctly re-opened." << endl;
    }

    // Read and echo entire file.

    // Note the read will advance the file pointer
    myObject.readIt(outputFile);
    while (!outputFile.eof())
    {
        cout << myObject;
        myObject.readIt(outputFile);
    }
    outputFile.close();

    // MESS with direct access, jump to a record to read it.
    outputFile.open(outputFileName, ios::in | ios::binary); // Same filename.

    long inputFileSize = fileSize(outputFileName);
    cout << "Size of file in bytes     = " << inputFileSize << endl;
    cout << "Bytes per record (object) = " << sizeof(myObject)
            << " (an int and a float)." << endl;
    cout << "Number of records in file = " << inputFileSize / sizeof(myObject)
            << endl;
    if (inputFileSize % sizeof(myObject) != 0)
    {
        cout << "Something is funny about that file size!!!" << endl;
    }

    positionReadHead(outputFile, 2);
    myObject.readIt(outputFile);
    cout << "Record 3 holds: " << myObject;

    positionReadHead(outputFile, 8);
    myObject.readIt(outputFile);
    cout << "Record 9 holds: " << myObject;

    positionReadHead(outputFile, 7);
    myObject.readIt(outputFile);
    cout << "Record 8 holds: " << myObject;
    outputFile.close();

    // Now modify with direct record update (after reading it in!)
    outputFile.open(outputFileName, ios::in | ios::out | ios::binary);
    cout << "We will now do direct access to update record 8 in that file."
            << endl;

    myObject.set(88, 3.14f);
    positionWriteHead(outputFile, 7);
    myObject.writeIt(outputFile);

    positionReadHead(outputFile, 7);
    myObject.readIt(outputFile);
    cout << "Record 8 now holds " << myObject; // Will see 88; 3.14
    cout << "Above line should show 88 and 3.14. " << endl;
    outputFile.close();


} // main()



public class Cleremedy 
{
	
	// Variables
	private String callersName;
	private String contactNumber;
	private String statedIssue;
	private String actionsTaken;
	private String ticketNumber;
	private boolean isResolved;
				
	// Constructor
	Cleremedy(String callersName, String ticketNumber, 
			String statedIssue, String actionsTaken, String contactNumber)  
	{
		this.callersName = callersName;
		this.contactNumber = contactNumber;
		this.statedIssue = statedIssue;
		this.actionsTaken = actionsTaken;
		this.ticketNumber = ticketNumber;
	}
	
	Cleremedy(String callersName, String statedIssue, String actionTaken, String contactNumber)
	{
		this.callersName = callersName;
		this.contactNumber = contactNumber;
		this.statedIssue = statedIssue;
		this.actionsTaken = actionsTaken;
	}
	
	
	Cleremedy()
	{
		callersName = "Customer Name";
		contactNumber = "123456789";
		statedIssue = "statedIssue";
		actionsTaken = "Steps";
		ticketNumber = "CR1234567890";
	}
	
	public String getCallersName()
	{
		return callersName;
	}
	
	public void setCallersName(String callersName)
	{
		this.callersName = callersName;
	}	
	
	
	public String getContactNumber()
	{
		return contactNumber;
	}
	
	public void setContactNumber(String contactNumber)
	{
		this.contactNumber = contactNumber;
	}
	
	
	public String getstatedIssue()
	{
		return statedIssue;
	}
	
	public void setStatedIssue(String statedIssue)
	{
		this.statedIssue = statedIssue;
	}
	
	public String getActionsTaken()
	{
		return actionsTaken;
	}
	
	public void setActionsTaken(String actionsTaken)
	{
		this.actionsTaken = actionsTaken;
	}
	
	public String getTicketNumber()
	{
		return ticketNumber;
	}
	
	public void setTicketNumber(String ticketNumber)
	{
		this.ticketNumber = ticketNumber;
	}
	
	public boolean getIsResolved()
	{
		return isResolved;
	}
	
	public void setIsResolved(boolean isResolved)
	{
		this.isResolved = isResolved;
	}
	
	public String toString()
	{
		return "Caller's Name: " + callersName + " | "
				+ "Callback Number: " + contactNumber + " | "
				+ "Ticket Number: " + ticketNumber + " | "
				+ "Stated Issue: " + statedIssue + " | "
				+ "Actions Taken: " + actionsTaken;
	}
	
	
}

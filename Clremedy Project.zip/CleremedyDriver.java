import java.awt.Color;
import java.awt.Container;

import javax.swing.*;
// Reference: Support.com remedy
// Written By: Tyrone Jefferon Jr.
// Based on Remedy Aid Tool by SDCv

public class CleremedyDriver extends JFrame
{
	public static void main(String[] args)
	{
		JFrame myFrame = new CleremedyGUI();
		myFrame.setTitle("Remedy Redux - By Tyrone J.");
		myFrame.setSize(800,330);
		myFrame.setLocationRelativeTo(null);
		myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		myFrame.getContentPane().setBackground(new Color(10,99,10));
		myFrame.setVisible(true);
	}

}

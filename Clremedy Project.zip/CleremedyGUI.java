import java.awt.*;
import java.awt.datatransfer.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
// Goals:
// Spacing for text box
// Abbraviations
// Scroll panes label issueTextbox
// Resize and reorganize
// N/A for ticket number
// Labeling properly
public class CleremedyGUI extends JFrame
{
	// Create 4 textfields 
	private JTextField jtfCallersName = new JTextField("Caller's Name: ");
	private JTextField jtfStatedIssue = new JTextField("Reported Issue: ");
	private JTextField jtfContactNumber = new JTextField("Callback #: ");
	private JTextField jtfTicketNumber = new JTextField("Ticket #: ");
	private JTextField jtfNotes = new JTextField("Notes: ");
	private JTextField jtfCauseCategory = new JTextField("");
	private JTextField jtfSolutionCategory = new JTextField("");
	
	// Labels for textFields
	private JLabel jlbCallersName = new JLabel("Caller's Name: ", JLabel.CENTER);
	private JLabel jlbStatedIssue = new JLabel("Reported Issue ", JLabel.CENTER);
	private JLabel jlbCallersNumber = new JLabel("Callback #: ", JLabel.CENTER);
	private JLabel jlbActionsTaken = new JLabel("Action Taken: ", JLabel.CENTER);
	private JLabel jlbTicketNumber = new JLabel("Ticket #: ",JLabel.CENTER);
	private JLabel jlbNotes = new JLabel("Notes: ");
	private JLabel jlbCause = new JLabel("      Cause Category");
	private JLabel jlbSolution = new JLabel("    Solution Category ");
	//private JLabel jlbCauseCategory = new JLabel("");
	//private JLabel jlbSolutionCategory = new JLabel("");
	
	// Text Areas
	private JTextArea jtaActionsTaken = new JTextArea(4,0);
	private JTextArea jtaNotes = new JTextArea(4,0);
	private JTextArea jtaR = new JTextArea("SDF");
	
	// Buttons
	private JButton jbtGenerate = new JButton("Generate");
	private JButton jbtCopy = new JButton("Copy");
	private JButton jbtClear = new JButton("Clear");
	
	// Scroll panes
	JScrollPane scrollPane = new JScrollPane(jtaActionsTaken);
	JScrollPane scrollPane2 = new JScrollPane(jtaNotes);
	
	// Font
	Font boldFont = new Font("SansSerif", Font.BOLD, 12);
	
	// Color
	//private Color white = new Color(255, 255, 255);
	private Color blue = new Color(100, 125, 255);
	
	// Tilted borders
	private TitledBorder tbCallerName = new TitledBorder("Caller Name");
	
	
	
	// JLists
	JComboBox jcbProblem = new JComboBox(new String[]
	{
		"--------------------------  Problem description -------------------------- ",
		"15003 - No connectivity - All",
		"15002 - No connectivity - Multiple",
		"15001 - No connectivity - Single",
		"14179 - Bridge Mode toggle",	
		"9887 - Slow Wifi connectivity",
		"15006 - Wireless - No connectivity - All",
		"15004 - Wireless - No connectivity - single",
		"15005 - Wireless - No connectivity - multiple",
		"15731 - Update SSID Name",
		"15730 - Update SSID password",
		"1129 -  Update Wifi settings",
		"15567 - Cannot connect",
		"14966 - Intermittent connectivity",
		"16176 - Captive Portal"
	});
	
	JComboBox jcbCause = new JComboBox(new String[]
	{
		"-------------------------- Cause Description -------------------------- ",
		"165 - Customer education",
		"1559 - Forgotten Wi-Fi password",
		"1564 - Having an issue with specific websites",
		"1550 - Help with email related problems",
		"1571 - Needs ports forwarded/Opened/Other firewall issues",
		"1562 - Wireless signal is intermittent or weak",
		"347 - Hardwire/Software Failure or Configuration",
		"1083 - Customer Ticket Follow up",
		"825 - Truck Roll",
		"112 - Unplanned Outage",
	});
	
	JComboBox jcbSolution = new JComboBox(new String[]
	{
		"-------------------------- Solution Description --------------------------",
		"2804 - Customer Education Hardware Software",
		"6045 - Reconfigured Wireless Security Settings",
		"6041 - Factory Reset Wireless Gateway",
		"9871 - Reset Customer's Browser Settings",
		"6067 - Reconfigured Mobile Device Settings",
		"9797 - Premise Truck Roll",
		"4763 - Modify SSID Name",
		"6085 - Reset Modem/Powercycled Router",
		"3300 - Configured customer email",
		"6092 - Toggled Bridge Mode",
		"6095 - Power Cycled Customer Equipment",
		"2846 - Transferred Call",
		"6057 - Referred CX to OEM for device issue"
	});

	public CleremedyGUI()
	{
		
		
		// Customizing buttons
		jbtGenerate.setBackground(new Color(59,89,182));
		jbtGenerate.setForeground(Color.WHITE);
		jbtGenerate.setFont(new Font("Verdana", Font.BOLD,12));
		
		jbtCopy.setBackground(new Color(59,89,182));
		jbtCopy.setForeground(Color.WHITE);
		jbtCopy.setFont(new Font("Verdana", Font.BOLD,12));
		
		jbtClear.setBackground(new Color(59,89,182));
		jbtClear.setForeground(Color.WHITE);
		jbtClear.setFont(new Font("Verdana", Font.BOLD,12));
		
		// Textbox fonts
		jtfCallersName.setFont(new Font("Verdana", Font.PLAIN, 14));
		jtfStatedIssue.setFont(new Font("Verdana", Font.PLAIN, 14));
		jtfContactNumber.setFont(new Font("Verdana", Font.PLAIN, 14));
		jtfTicketNumber.setFont(new Font("Verdana", Font.PLAIN, 14));
		jtaActionsTaken.setFont(new Font("Verdana", Font.PLAIN, 14));
		jtaNotes.setFont(new Font("Verdana", Font.PLAIN, 14));
		jcbProblem.setFont(new Font("Verdana", Font.PLAIN, 9));
		jcbCause.setFont(new Font("Verdana", Font.PLAIN, 9));
		jcbSolution.setFont(new Font("Verdana", Font.PLAIN,9));
		
		jtfCauseCategory.setFont(new Font("Verdana", Font.PLAIN, 14));
		jtfSolutionCategory.setFont(new Font("Verdana", Font.PLAIN, 14));
		
		jlbCause.setFont(new Font("Verdana", Font.BOLD, 14));
		jlbSolution.setFont(new Font("Verdana", Font.BOLD, 14));
		
		// 
		JPanel test = new JPanel(new GridLayout(0, 2, 8, 8));
		JPanel p1 = new JPanel(new GridLayout(4, 2, 8, 8));
		JPanel subp1 = new JPanel(new BorderLayout());
			jlbCallersName.setFont(boldFont);
			jlbCallersNumber.setFont(boldFont);
			jlbStatedIssue.setFont(boldFont);
			jlbActionsTaken.setFont(boldFont);
			jlbTicketNumber.setFont(boldFont);
			jlbNotes.setFont(boldFont);
			
			
			//p1.add(jlbCallersName);
			p1.add(jtfCallersName);
			//p1.add(jlbStatedIssue);
			p1.add(jtfStatedIssue);
			//p1.add(jlbCallersNumber);
			p1.add(jtfContactNumber);
			//p1.add(jlbTicketNumber);
			p1.add(jtfTicketNumber);
			
		
		JPanel p2 = new JPanel(new GridLayout(1,1,8,8));
			jtaActionsTaken.setLineWrap(true);
			jtaActionsTaken.setWrapStyleWord(true);
			p2.add(scrollPane, jtaActionsTaken);
		
		JPanel p3 = new JPanel(new FlowLayout(FlowLayout.CENTER, 3, 3));
			//jbtCopy.setBackground(blue);
			//jbtCopy.setForeground(white);
		
			p3.add(jbtGenerate);
			p3.add(jbtCopy);
			p3.add(jbtClear);
		
		JPanel p4 = new JPanel(new BorderLayout(8,8));
			JPanel subp4forlists = new JPanel(new GridLayout(3,1));
			JPanel subp4forLabels = new JPanel(new GridLayout(2,2,8,8));
			
			subp4forlists.add(jcbProblem);
			subp4forlists.add(jcbCause);
			subp4forlists.add(jcbSolution);
			
			subp4forLabels.add(jlbCause);
			subp4forLabels.add(jlbSolution);
			subp4forLabels.add(jtfCauseCategory);
			subp4forLabels.add(jtfSolutionCategory);
			
			jtaNotes.setLineWrap(true);
			jtaNotes.setWrapStyleWord(true);
			
			p4.add(subp4forLabels, BorderLayout.SOUTH);
			p4.add(subp4forlists, BorderLayout.NORTH);
			p4.add(jtaNotes);

		JPanel p5 = new JPanel(new BorderLayout(8,8));
			subp1.add(p1, BorderLayout.NORTH);
			subp1.add(p2, BorderLayout.CENTER);
			p5.add(subp1, BorderLayout.CENTER);
			p5.add(p3, BorderLayout.SOUTH);
			p5.add(p4, BorderLayout.EAST);
			
		subp1.add(p1, BorderLayout.NORTH);
		subp1.add(p2, BorderLayout.CENTER);
		p5.add(subp1, BorderLayout.CENTER);
		p5.add(p3, BorderLayout.SOUTH);
		p5.add(p4, BorderLayout.WEST);
		
		add(p5);
		
		// Coloring panels
		//subp1.setBackground(new Color(60,60,60));
		//p5.setBackground(new Color(60,60,60));
		//p4.setBackground(new Color(60,60,60));
		//p3.setBackground(new Color(60,60,60));
		//p2.setBackground(new Color(60,60,60));
		//p1.setBackground(new Color(60,60,60));
		//jlbCause.setBackground(new Color(10,99,10));
		
		// Coloring textboxs
		//jtfCallersName.setBackground(new Color(100,100,100));
		//jtfStatedIssue.setBackground(new Color(60,60,60));
		//jtfContactNumber = new JTextField("Callback #: ");
		//jtfTicketNumber = new JTextField("Ticket #: ");
		//jtfNotes = new JTextField("Notes: ");
		//jtfCauseCategory = new JTextField("");
		//jtfSolutionCategory = new JTextField("")
		// Registering Button Listeners
		jtfTicketNumber.addFocusListener(new ticketNumberFocusListener());
		jtfContactNumber.addFocusListener(new contactNumberFocusListener());
		jtfStatedIssue.addFocusListener(new statedIssueFocusListener());
		jtfCallersName.addFocusListener(new callersNameFocusListener());
		
		jbtGenerate.addActionListener(new generateButtonListener());
		jbtCopy.addActionListener(new copyButtonListener());
		jbtClear.addActionListener(new clearButtonListener());
		
		jcbCause.addActionListener(new causeComboBoxListener());
		jcbSolution.addActionListener(new solutionComboBoxListener());
	}
	
//======================================= Listeners ======================================= 
	private class ticketNumberFocusListener implements FocusListener
	{
		@Override
		public void focusGained(FocusEvent e)
		{
			jtfTicketNumber.selectAll();
		}
		
		@Override
		public void focusLost(FocusEvent e)
		{}
			
	} // ticketNumberFocusListener()
	
	private class contactNumberFocusListener implements FocusListener
	{
		@Override
		public void focusGained(FocusEvent e)
		{
			jtfContactNumber.selectAll();
		}
		
		@Override
		public void focusLost(FocusEvent e)
		{}		
	} // contactNumberFocusListener
	
	private class statedIssueFocusListener implements FocusListener
	{
		@Override
		public void focusGained(FocusEvent e)
		{
			jtfStatedIssue.selectAll();
		}
		
		@Override
		public void focusLost(FocusEvent e)
		{}		
	} // statedIssueFocusListener()
	
	private class callersNameFocusListener implements FocusListener
	{
		@Override
		public void focusGained(FocusEvent e)
		{
			jtfCallersName.selectAll();
			//jtfCallersName.setBackground(Color.yellow);
		}
		
		@Override
		public void focusLost(FocusEvent e)
		{
			//if(jtfCallersName.getText().equals(""))
			//	jtfCallersName.setText("Caller's Name");
			//jtfCallersName.setBackground(Color.white);
		}
	}// callersNameFocusListener() 
	
	private class generateButtonListener implements ActionListener
	{
		@Override
		public void actionPerformed(ActionEvent e)
		{
			// Initialization
			String callersName = " ";
			String contactNumber = " ";
			String statedIssue = " ";
			String actionsTaken = " ";
			String ticketNumber = " ";
			
			Cleremedy caller = new Cleremedy(callersName, ticketNumber, 
					statedIssue, actionsTaken, contactNumber);
			
			// Gather from the textbox and textarea
			caller.setCallersName(jtfCallersName.getText());
			caller.setContactNumber(jtfContactNumber.getText());
			caller.setStatedIssue(jtfStatedIssue.getText());
			caller.setActionsTaken(jtaActionsTaken.getText());
			caller.setTicketNumber(jtfTicketNumber.getText());
			
			// Output the resaults
			jtaNotes.setText(caller.toString());			
		}
	}
	
	private class clearButtonListener implements ActionListener
	{
		@Override
		public void actionPerformed(ActionEvent e)
		{	
			// Reset the text boxes
			jtfCallersName.setText("Caller's Name: ");
			jtfContactNumber.setText("Callback #: ");
			jtfStatedIssue.setText("Reported Issue: ");
			jtfCauseCategory.setText("");
			jtfSolutionCategory.setText("");
			jtaActionsTaken.setText(" ");
			jtfTicketNumber.setText("Ticket #: ");
			jtaNotes.setText(" ");
			
			// Reset the Combo Boxes
			jcbProblem.setSelectedIndex(0);
			jcbCause.setSelectedIndex(0);
			jcbSolution.setSelectedIndex(0);
		}
	}
	
	private class copyButtonListener implements ActionListener
	{
		@Override
		public void actionPerformed(ActionEvent e)
		{

			// Copy Text to clipboard
			StringSelection stringSelection = new StringSelection(jtaNotes.getText());
			Clipboard clipBoard = Toolkit.getDefaultToolkit().getSystemClipboard();
			clipBoard.setContents(stringSelection, null);
						
			// Highlight text to indicate copy button was pressed
			jtaNotes.requestFocus();
			jtaNotes.selectAll();
		}
	}
	
	private class causeComboBoxListener implements ActionListener
	{
		@Override
		public void actionPerformed(ActionEvent e)
		{
			if(jcbCause.getSelectedItem().equals("165 - Customer education")) 
			{
				jtfCauseCategory.setText("Customer");
				jtfSolutionCategory.setText("Customer");
				jcbSolution.setSelectedIndex(1);
			}
				
			// SLOPPY...maybe use the codes and make seperate objects?
			else if(jcbCause.getSelectedItem().equals("1559 - Forgotten Wi-Fi password") || 
					jcbCause.getSelectedItem().equals("1564 - Having an issue with specific websites") ||
					jcbCause.getSelectedItem().equals("1550 - Help with email related problems")||
					jcbCause.getSelectedItem().equals("1571 - Needs ports forwarded/Opened/Other firewall issues")||
					jcbCause.getSelectedItem().equals("1562 - Wireless signal is intermittent or weak")
					)
			{
				jtfCauseCategory.setText("Xfinity Signature Support");
			}
			
			else if(jcbCause.getSelectedItem().equals("347 - Hardwire/Software Failure or Configuration"))
				jtfCauseCategory.setText("Vendor");
			else if(jcbCause.getSelectedItem().equals("1083 - Customer Ticket Follow up"))
				jtfCauseCategory.setText("Video");
			
			else if(jcbCause.getSelectedItem().equals("825 - Truck Roll") ||
					jcbCause.getSelectedItem().equals("112 - Unplanned Outage"))
				jtfCauseCategory.setText("Comcast");
			else
				jtfCauseCategory.setText("");
			
			if(jcbCause.getSelectedItem().equals("1559 - Forgotten Wi-Fi password"))
				jcbSolution.setSelectedIndex(2);
		}
	}
	
	private class solutionComboBoxListener implements ActionListener
	{
		@Override
		public void actionPerformed(ActionEvent e)
		{
			if(jcbSolution.getSelectedItem().equals("2804 - Customer Education Hardware Software") ||
					jcbSolution.getSelectedItem().equals("6045 - Reconfigured Wireless Security Settings") ||
					jcbSolution.getSelectedItem().equals("6041 - Factory Reset Wireless Gateway") ||
					jcbSolution.getSelectedItem().equals("2804 - Customer Education Hardware Software") ||
					jcbSolution.getSelectedItem().equals("9871 - Reset Customer's Browser Settings") || 
					jcbSolution.getSelectedItem().equals("6067 - Reconfigured Mobile Device Settings") ||
					jcbSolution.getSelectedItem().equals("9797 - Premise Truck Roll") ||
					jcbSolution.getSelectedItem().equals("4763 - Modify SSID Name") || 
					jcbSolution.getSelectedItem().equals("6095 - Power Cycled Customer Equipment") || 
					jcbSolution.getSelectedItem().equals("3300 - Configured customer email") ||
					jcbSolution.getSelectedItem().equals("6092 - Toggled Bridge Mode"))
			{
				jtfSolutionCategory.setText("Customer");
			}
			else if(jcbSolution.getSelectedItem().equals("6085 - Reset Modem/Powercycled Router"))
				jtfSolutionCategory.setText("Premise Equipment");
			else if(jcbSolution.getSelectedItem().equals("2846 - Transferred Call") || 
					jcbSolution.getSelectedItem().equals("3297 - Recommended replacement of WG device"))
			{
				jtfSolutionCategory.setText("Billing");
			}
			else if(jcbSolution.getSelectedItem().equals("6057 - Referred CX to OEM for device issue"))
				jtfSolutionCategory.setText("Hardware/Software");
			else
				jtfSolutionCategory.setText("");
		}
	}
} // Cleremedy

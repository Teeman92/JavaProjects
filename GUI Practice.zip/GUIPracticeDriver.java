
import javax.swing.*;
import java.awt.*;
import javax.swing.border.*;


public class GUIPracticeDriver
{
	public static void main(String[] args)
	{
		JFrame myFrame = new GUIPractice();
		myFrame.setTitle("THIS IS A GUI");
		myFrame.setSize(550, 120);
		myFrame.setLocationRelativeTo(null);
		myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		myFrame.setVisible(true);
	}
}
	
	



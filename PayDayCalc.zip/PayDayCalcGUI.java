import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.border.*;


public class PayDayCalcGUI extends JFrame
{
	// Create 3 textfield: Needs, wants, savings and paidBalance
	private JTextField jtfNeeds = new JTextField("0.00");
	private JTextField jtfWants = new JTextField("0.00");
	private JTextField jtfSavings = new JTextField("0.00");
	private JTextField jtfPaidBalance = new JTextField();
	
	// Create two buttons jbtClear and jbtCalculate
	private JButton jbtClear = new JButton("Clear");
	private JButton jbtCalculate = new JButton("Calculate");
	
	// Create 3 labels next to the text fields
	private JLabel jlblNeeds = new JLabel("Needs:");
	private JLabel jlblWants = new JLabel("Wants:");
	private JLabel jlblSavings = new JLabel("Savings:");
	
	// Titled Borders
	
	
	public PayDayCalcGUI()
	{
		JPanel p1 = new JPanel(new BorderLayout());
		p1.add(jtfPaidBalance);
		p1.setBorder(new TitledBorder("Enter amount here"));
		
		// Add labels and then textfields to the panel
		JPanel p2 = new JPanel(new GridLayout(3,3,5,5));
		JPanel subp2 = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		p2.add(jlblNeeds);
		p2.add(jtfNeeds);
		p2.add(jlblWants);
		p2.add(jtfWants);
		p2.add(jlblSavings);
		p2.add(jtfSavings);
		
		// Add buttons to the bottom of the frame
		JPanel p3 = new JPanel(new FlowLayout(FlowLayout.CENTER));
		p3.add(jbtCalculate);
		p3.add(jbtClear);
		
		
		// Add panels to the frame
		add(p1, BorderLayout.NORTH);
		add(p2, BorderLayout.CENTER);
		add(p3, BorderLayout.SOUTH);
		
		// Register listeners
		jbtCalculate.addActionListener(new CalculateButtonListener());
		jbtClear.addActionListener(new ClearButtonListener());
	}
	
	// Create a button listener that calculates
	private class CalculateButtonListener implements ActionListener
	{
		@Override
		public void actionPerformed(ActionEvent e)
		{
			double paidBalance = Double.parseDouble(jtfPaidBalance.getText());
			double needs = 0.0;
			double wants = 0.0;
			double savings = 0.0;
			
			PaydayCalc payday = new PaydayCalc(paidBalance, needs, wants, savings);
			
			// Display resualts after calculation
			jtfNeeds.setText(String.format("%.2f", payday.getNeedsBalance()));
			jtfWants.setText(String.format("%.2f", payday.getWantsBalance()));
			jtfSavings.setText(String.format("%.2f", payday.getSavingsBalance()));
			
		}
	}
	
	private class ClearButtonListener implements ActionListener
	{
		@Override
		public void actionPerformed(ActionEvent e)
		{
			jtfPaidBalance.setText("");
			jtfWants.setText("0.00");
			jtfNeeds.setText("0.00");
			jtfSavings.setText("0.00");
		}
	}
	
}

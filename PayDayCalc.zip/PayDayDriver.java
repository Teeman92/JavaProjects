import javax.swing.*;
import java.awt.*;
// This is a basic yet somewhat useful calculator, just for practicing purposes
public class PayDayDriver extends JFrame
{
	public static void main(String[] args)
	{
		JFrame frame = new PayDayCalcGUI();
		frame.setTitle("Pay Day Calculator - By Tee-man");
		frame.setSize(500,200);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}// main()
}// PayDayDriver

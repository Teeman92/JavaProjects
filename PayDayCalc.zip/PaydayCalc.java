import javax.swing.*;

public class PaydayCalc extends JFrame
{
	// Instance variables
	private double paidBalance;
	private double needsBalance;
	private double wantsBalance;
	private double savingsBalance;
	
	PaydayCalc()
	{
		paidBalance = 0.0;
		needsBalance = 0.0;
		wantsBalance = 0.0;
		savingsBalance = 0.0;
	}
	
	PaydayCalc(double paidBalance, double needsBalance, double wantsBalance, double savingsBalance)
	{
		this.paidBalance = paidBalance;
		this.needsBalance = needsBalance;
		this.wantsBalance = wantsBalance;
		this.savingsBalance = savingsBalance;
	}
	
	public double getPaidBalance()
	{
		return paidBalance;
	}
	
	public void setPaidBalance(double paidBalance)
	{
		this.paidBalance = paidBalance;
	}
	
	public double getNeedsBalance()
	{
		needsBalance = getPaidBalance() * 0.5;
		return needsBalance;
	}
	
	public void setNeedsBalance(double needsBalance)
	{
		this.needsBalance = needsBalance;
	}
	
	public double getWantsBalance()
	{
		wantsBalance = getPaidBalance() * 0.3;
		return wantsBalance;
	}
	
	public void setWantsBalance(double wantsBalance)
	{
		this.wantsBalance = wantsBalance;
	}
	
	public double getSavingsBalance()
	{
		savingsBalance = paidBalance * 0.2;
		return savingsBalance;
	}
	
	public void setSavingsBalance(double savingsBalance)
	{
		this.savingsBalance = savingsBalance;
	}
}

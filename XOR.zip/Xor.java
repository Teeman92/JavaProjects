// Written by: Tyrone Jefferson Jr.
// Referenced xor90.java and xor.c

import java.lang.Math.*;

public class Xor 
{
	private final int numLayers = 3;
	private final int maxNodes = 6;
	
	final int numInputs = 2;
	final int numOutputs = 1;
	
	private final int[] nodes = {2,6,1};
	
	private final double dscalemarg = 0.05;
	
	private double[] act;
	private double[] net;
	
	private final double[] iMin = {+0, +0};
	private final double[] iMax = {+1, +1};
	private final double[] oMin = {+0};
	private final double[] oMax = {+1};
	
	private double[] weights = 
	{
		+2.14329682041357, +1.99042492654128, -0.20964826508162,
		-1.72348873326539, -1.90929083474614, +2.67297742773119,
		+0.64856000540333, -2.08489145375501, -0.39010682525955,
		+3.13178024741631, +3.11426906741869, -0.84102567491035,
		-1.07881582396412, -1.37027847108807, +1.61905136230156,
		+1.14240756298787, +0.71670422745476, -0.93641069397533,
		+6.67948213040428, +6.94426762328211, +1.50017112983106,
		+8.94489968243179, -0.13958647134134, -10.41137254828693,
		-12.16044759679642
	};
	
	public Xor()
	{
		act = new double[maxNodes];
		net = new double[maxNodes];
	}
	
	public double ann(double[] In, double[] Target, double[] Out)
	{
		double dMin, dMax;
		int wcnt;
		int i, j, lay;
		
		for(i = 0; i < numInputs; i++)
		{
			if(iMin[i] != iMax[i])
			{
				dMin = iMin[i] - dscalemarg * (iMax[i] - iMin[i]);
				dMax = iMax[i] + dscalemarg * (iMax[i] - iMin[i]);
				act[i] = (In[i] - dMin) / (dMax - dMin);
			}// if
			else
			{
				act[i] = 0;
			}// else
		}// for(i)
		wcnt = 0;
		
		for(lay = 1; lay < numLayers; lay++)
		{
			for(j = 0; j < nodes[lay]; j++)
			{
				net[j] = 0;
				for(i = 0; i < nodes[lay-1]; i++)
				{
					net[j] += (weights[wcnt] * act[i]);
					wcnt++;
				}//for(i=0)
				net[j] += weights[wcnt];
				wcnt++;
			}//for(j)
			for(j = 0; j < nodes[lay]; j++)
			{
				act[j] = 1.0 / (1.0 + Math.exp(-net[j]));
			}//for(j=0)
		}//for(lay)
		
		double delta = 0.0D;
		
		for(i = 0; i < numOutputs; i++)
		{
			if(oMin[i] != oMax[i])
			{
				dMin = oMin[i] - dscalemarg * (oMax[i] - oMin[i]);
				dMax = oMax[i] + dscalemarg * (oMax[i] - oMin[i]);
				Out[i] = dMin + (dMax - dMin) * act[i];
			}
			else
			{
				Out[i] = oMin[i];
			}
			delta += ((Target[i] - Out[i]) * (Target[i] - Out[i]));
		}// for(i = 0)
		
		delta = Math.sqrt(delta / numOutputs);
		return delta;
	}// ann()
	
}




























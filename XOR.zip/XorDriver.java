import javax.swing.*;

public class XorDriver extends JFrame
{
	public static void main(String[] args)
	{
		
		
		JFrame myFrame = new XorGUI();
		myFrame.setTitle("XOR");
		myFrame.setSize(230,170);
		myFrame.setLocationRelativeTo(null);
		myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		myFrame.setVisible(true);
	  /*
		double[] dInput = new double[2];
		double[] dOutput = new double[1];
		double[] target = new double[6];
		
		Xor obj = new Xor();
		
		
		for(int in1 = 0; in1 < 2; in1++)
		{
			for(int in2 = 0; in2 < 2; in2++)
			{
				dInput[0] = (double)in1;
				dInput[1] = (double)in2;
				obj.ann(dInput, target, dOutput);
				System.out.println(in1 + "\t" + in2 + "\t\t" + dOutput[0]);
				
			}
		}
		*/
		
	}
}

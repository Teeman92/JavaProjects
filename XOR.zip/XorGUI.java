import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

// Goals:
// 1) Design a basic GUI, nothing fancy yet
public class XorGUI extends JFrame
{
	// create 3 textfields
	private JTextField jtfInput1 = new JTextField();
	private JTextField jtfInput2 = new JTextField();
	private JTextField jtfOutput = new JTextField();
	
	// create 3 labels
	private JLabel jlbInput1 = new JLabel("Input 1", SwingConstants.CENTER);
	private JLabel jlbInput2 = new JLabel("Input 2", SwingConstants.CENTER);
	private JLabel jlbOutput = new JLabel("Output", SwingConstants.CENTER);
	
	// create 2 buttons
	private JButton jbtClear = new JButton("Clear");
	private JButton jbtCalculate = new JButton("Calculate");
	
	public XorGUI()
	{
		// Setting up GUI
		
		// Label and Input1box
		//JPanel mainGUI = new JPanel(new BorderLayout(5,5));
		JPanel mainGUI = new JPanel(new FlowLayout());
	
		JPanel inputMenu1 = new JPanel(new BorderLayout(1,1));
			inputMenu1.add(jlbInput1, BorderLayout.NORTH);
			inputMenu1.add(jtfInput1, BorderLayout.CENTER);
			
		JPanel inputMenu2 = new JPanel(new BorderLayout(1,1));
			inputMenu2.add(jlbInput2, BorderLayout.NORTH);
			inputMenu2.add(jtfInput2, BorderLayout.CENTER);
			
		JPanel inputPane = new JPanel(new GridLayout(2,90));
			inputPane.add(inputMenu1);
			inputPane.add(inputMenu2);
		
		JPanel outputMenu = new JPanel(new BorderLayout(1,1));
			outputMenu.add(jlbOutput, BorderLayout.NORTH);
			outputMenu.add(jtfOutput, BorderLayout.SOUTH);
			
		JPanel buttonPane = new JPanel(new FlowLayout());
			buttonPane.add(jbtClear);
			buttonPane.add(jbtCalculate);
			
		mainGUI.add(inputPane, BorderLayout.WEST);
		mainGUI.add(outputMenu, BorderLayout.EAST);
		mainGUI.add(buttonPane, BorderLayout.SOUTH);
		add(mainGUI);
		
		//Initialize Listeners
		jbtCalculate.addActionListener(new calculateButtonListener());
		jbtClear.addActionListener(new clearButtonListener());
	}
	// Listeners
	private class calculateButtonListener implements ActionListener
	{
		@Override
		public void actionPerformed(ActionEvent e)
		{
			Xor obj = new Xor();
			
			double[] dInput = new double[2];
			double[] dOutput = new double[1];
			double[] target = new double[6];
			
			// Gather input from textboxes
			dInput[0] = Double.parseDouble(jtfInput1.getText());
			dInput[1] = Double.parseDouble(jtfInput2.getText());
			
			// Output to jtfOutput
			obj.ann(dInput, target, dOutput);
			
			// Output to jtfOutput
			jtfOutput.setText(String.format("%.3f", dOutput[0]));
			
		}
	}
	
	private class clearButtonListener implements ActionListener
	{
		@Override
		public void actionPerformed(ActionEvent e)
		{
			// Reset the text boxes
			jtfInput1.setText("");
			jtfInput2.setText("");
			jtfOutput.setText("");
		}
	}
}
